
public class Main {

	public static void main(String[] args) {
		LDoblePer per = new LDoblePer();
		per.adifinal("Juan", "Gerente");
		per.adifinal("Maria", "Sub gerente");
		per.adifinal("CArlos", "Guardia");
		per.adifinal("Mario", "Ventas");
		per.adifinal("Adrian", "Supervisor");
		//mostrarRec(per.getP());
		LSimplePro pro = new LSimplePro();
		pro.adiprincipio("Jaron", "Ceramica", 1990, "Envio estandar");
		pro.adiprincipio("Pintura", "artesania", 731, "Envio Contra reembolso");
		pro.adiprincipio("Aretes", "Joyeria", 6652, "Envio fragil");
		pro.adiprincipio("Ropero", "Muebleria", 324, "Envio pesado");
		pro.adiprincipio("Flores", "Decoracion", 5321, "Envio estandar");
		//pro.mostrarR(pro.getP());
		Empresa el = new Empresa("Soboce", "mediana", "nacinal");
		
		//*********************************************************
		LDoblePer per1 = new LDoblePer();
		per1.adifinal("Juan11", "Gerente11");
		per1.adifinal("Maria11", "Sub gerente11");
		per1.adifinal("CArlos11", "Guardia11");
		per1.adifinal("Mario11", "Ventas11");
		per1.adifinal("Adrian11", "Supervisor11");
		
		LSimplePro pro1 = new LSimplePro();
		pro1.adiprincipio("Jaron11", "Ceramica11", 1990, "Envio estandar");
		pro1.adiprincipio("Pintura11", "artesania11", 731, "Envio Contra reembolso");
		pro1.adiprincipio("Aretes11", "Joyeria11", 6652, "Envio fragil");
		pro1.adiprincipio("Ropero11", "Muebleria11", 324, "Envio pesado");
		pro1.adiprincipio("Flores11", "Decoracion11", 5321, "Envio estandar");
		
		Empresa e2 = new Empresa("ABC", "mediana", "nacinal");
		
		
		//***********************************************************

		LDoblePer per2 = new LDoblePer();
		per2.adifinal("Carla22", "Gerente22");
		per2.adifinal("Jorge22", "Sub gerente22");
		per2.adifinal("Roger22", "Guardia22");
		per2.adifinal("Cesar22", "Ventas22");
		per2.adifinal("Adriana22", "Supervisor22");

		LSimplePro pro2 = new LSimplePro();
		pro2.adiprincipio("Jaron22", "Ceramica22", 1990, "Envio estandar");
		pro2.adiprincipio("Pintura22", "artesania22", 731, "Envio Contra reembolso");
		pro2.adiprincipio("Aretes22", "Joyeria22", 6652, "Envio fragil");
		pro2.adiprincipio("Ropero22", "Muebleria22", 324, "Envio pesado");
		pro2.adiprincipio("Flores22", "Decoracion22", 5321, "Envio estandar");
		
		Empresa e3 = new Empresa("Entel", "Grande", "Internacionl");
		
		LDobleSta s1 = new LDobleSta();
		s1.adifinal(el, pro, per);
		s1.adifinal(e2, pro1, per1);
		s1.adifinal(e3, pro2, per2);
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		LDoblePer per11 = new LDoblePer();
		per11.adifinal("Juan33", "Gerente33");
		per11.adifinal("Maria33", "Sub gerente33");
		per11.adifinal("CArlos33", "Guardia33");
		per11.adifinal("Mario33", "Ventas33");
		per11.adifinal("Adrian33", "Supervisor33");
		
		LSimplePro pro11 = new LSimplePro();
		pro11.adiprincipio("Jaron33", "Ceramica33", 1990, "Envio estandar");
		pro11.adiprincipio("Pintura33", "artesania33", 731, "Envio Contra reembolso");
		pro11.adiprincipio("Aretes33", "Joyeria33", 6652, "Envio fragil");
		pro11.adiprincipio("Ropero33", "Muebleria33", 324, "Envio pesado");
		pro11.adiprincipio("Flores33", "Decoracion33", 5321, "Envio estandar");
		
		Empresa el2 = new Empresa("AAIB", "mediana", "nacinal");
		
		//*********************************************************
		LDoblePer per12 = new LDoblePer();
		per12.adifinal("Juan44", "Gerente44");
		per12.adifinal("Maria44", "Sub gerente44");
		per12.adifinal("CArlos44", "Guardia44");
		per12.adifinal("Mario44", "Ventas44");
		per12.adifinal("Adrian44", "Supervisor44");
		
		LSimplePro pro12 = new LSimplePro();
		pro12.adiprincipio("Jaron44", "Ceramica44", 1990, "Envio estandar");
		pro12.adiprincipio("Pintura44", "artesania44", 731, "Envio Contra reembolso");
		pro12.adiprincipio("Aretes44", "Joyeria44", 6652, "Envio fragil");
		pro12.adiprincipio("Ropero44", "Muebleria44", 324, "Envio pesado");
		pro12.adiprincipio("Flores44", "Decoracion44", 5321, "Envio estandar");
		
		Empresa e13 = new Empresa("AV�COLA ROL�N", "mediana", "nacinal");
		
		
		//***********************************************************

		LDoblePer per22 = new LDoblePer();
		per22.adifinal("Carla55", "Gerente55");
		per22.adifinal("Jorge55", "Sub gerente55");
		per22.adifinal("Roger55", "Guardia55");
		per22.adifinal("Cesar55", "Ventas55");
		per22.adifinal("Adriana5", "Supervisor55");

		LSimplePro pro22 = new LSimplePro();
		pro22.adiprincipio("Jaron55", "Ceramica55", 1990, "Envio estandar");
		pro22.adiprincipio("Pintura55", "artesania55", 731, "Envio Contra reembolso");
		pro22.adiprincipio("Aretes55", "Joyeria55", 6652, "Envio fragil");
		pro22.adiprincipio("Ropero55", "Muebleria55", 324, "Envio pesado");
		pro22.adiprincipio("Flores55", "Decoracion55", 5321, "Envio estandar");
		
		Empresa e23 = new Empresa("ALMANZA CORP", "Grande", "Internacionl");

		
		
		
		LDobleSta s2 = new LDobleSta();
		s2.adifinal(el2, pro11, per11);
		s2.adifinal(e13, pro12, per12);
		s2.adifinal(e23, pro22, per22);
		
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		LDoblePer per23 = new LDoblePer();
		per23.adifinal("Juan66", "Gerente66");
		per23.adifinal("Maria66", "Sub gerente66");
		per23.adifinal("CArlos66", "Guardia66");
		per23.adifinal("Mario66", "Ventas66");
		per23.adifinal("Adrian66", "Supervisor66");
		
		LSimplePro pro23 = new LSimplePro();
		pro23.adiprincipio("Jaron66", "Ceramica66", 1990, "Envio estandar");
		pro23.adiprincipio("Pintura66", "artesania66", 731, "Envio Contra reembolso");
		pro23.adiprincipio("Aretes66", "Joyeria66", 6652, "Envio fragil");
		pro23.adiprincipio("Ropero66", "Muebleria66", 324, "Envio pesado");
		pro23.adiprincipio("Flores66", "Decoracion66", 5321, "Envio estandar");
		
		Empresa e230 = new Empresa("ANDES TR�PICO", "mediana", "nacinal");
		
		//*********************************************************
		LDoblePer per24 = new LDoblePer();
		per24.adifinal("Juan77", "Gerente");
		per24.adifinal("Maria77", "Sub gerente77");
		per24.adifinal("CArlos77", "Guardia77");
		per24.adifinal("Mario77", "Ventas77");
		per24.adifinal("Adrian77", "Supervisor77");
		
		LSimplePro pro24 = new LSimplePro();
		pro24.adiprincipio("Jaron77", "Ceramica77", 1990, "Envio estandar");
		pro24.adiprincipio("Pintura77", "artesania77", 731, "Envio Contra reembolso");
		pro24.adiprincipio("Aretes77", "Joyeria77", 6652, "Envio fragil");
		pro24.adiprincipio("Ropero77", "Muebleria77", 324, "Envio pesado");
		pro24.adiprincipio("Flores77", "Decoracion77", 5321, "Envio estandar");
		
		Empresa e24 = new Empresa("BOLPEGAS", "mediana", "nacinal");
		
		
		//***********************************************************

		LDoblePer per25 = new LDoblePer();
		per25.adifinal("Carla88", "Gerente");
		per25.adifinal("Roger88", "Guardia88");
		per25.adifinal("Cesar88", "Ventas88");
		per25.adifinal("Adriana88", "Supervisor88");

		LSimplePro pro25 = new LSimplePro();
		pro25.adiprincipio("Jaron88", "Ceramica88", 1990, "Envio estandar");
		pro25.adiprincipio("Pintura88", "artesania88", 731, "Envio Contra reembolso");
		pro25.adiprincipio("Aretes88", "Joyeria88", 6652, "Envio fragil");
		pro25.adiprincipio("Ropero88", "Muebleria88", 324, "Envio pesado");
		pro25.adiprincipio("Flores88", "Decoracion88", 5321, "Envio estandar");
		
		Empresa e25 = new Empresa("BEBIDAS S.A.", "Grande", "Internacionl");
		
		LDobleSta s3 = new LDobleSta();
		s3.adifinal(e230, pro23, per23);
		s3.adifinal(e24, pro24, per24);
		s3.adifinal(e25, pro25, per25);
		//mostrarRS(s1.getP());
		
		
		
		
		LSimpleBN d = new LSimpleBN();
		d.adiprincipio("Rojo", 2, s1);
		d.adiprincipio("Rojo", 1, s2);
		d.adiprincipio("verda", 1, s3);
		//d.mostrar();
		//mostrarRBN(d.getP());
		revisar(d.getP(), "ANDES TR�PICO");
		//Mostrar los niveles del bloque color x
		System.out.println("Niveles del color rojo");
		mostrarBloqX(d.getP(), "Rojo");
		recorido(d.getP());
		//nro personal de cada empresa
		
	}
	public static boolean verifica(NodoPro z, String x) {
		if (z != null) {
			if (z.getNombre().equals(x)) {
				return true;
			}
			return verifica(z.getSig(), x);
		}else {
			return false;
		}
	}
	public static void recorido(NodoBN w) {
		if (w != null) {
			nroPersonal(w.getC().getP());
			recorido(w.getSig());
		}
	}
	public static void nroPersonal(NodoSta r) {
		if (r != null) {
			r.getE().mostrar();
			System.out.println(r.getE().getNombre() + " -----------> " + contar(r.getA().getP()));
			nroPersonal(r.getSig());
		}
	}
	public static int contar(NodoPer r) {
		if (r != null) {
			return contar(r.getSig())+1;
		}else {
			return 0;
		}
		
	}

	public static int contar2(NodoPer r) {
		if (r != null) {
			int c = contar2(r.getSig());
			return c+1;
		}else {
			return 0;
		}
	}

	public static int contar3(NodoPer r, int c) {
		if (r != null) {
			return contar3(r.getSig(), c+1);
		}else {
			return 0;
		}
	}
	public static void mostrarBloqX(NodoBN p, String x) {
		if (p != null) {
			if (p.getColor().equals(x)) {
				System.out.println(" " + p.getNivel());
				
			}
			mostrarBloqX(p.getSig(), x);
		}
		
	}
	public static void revisar(NodoBN r, String x) {
		if (r != null) {
			buscaRec(r.getC().getP(), x);
			revisar(r.getSig(), x);
		}
	}
	public static void buscaRec(NodoSta r, String x) {
		if (r != null) {
			if (r.getE().getNombre().equals(x)) {
				r.getB().mostrarR(r.getB().getP());
			}
			buscaRec(r.getSig(), x);
		}
	}
	public static void mostrarRBN(NodoBN r) {
		if (r != null) {
			System.out.println("[ " + r.getColor() + "  " + r.getNivel()+ "  ]");
			mostrarRS(r.getC().getP());
			mostrarRBN(r.getSig());
		}
	}

	public static void mostrarRS(NodoSta p) {
		if (p!=null) {
			p.getE().mostrar();
			mostrarRec(p.getA().getP());
			p.getB().mostrarR(p.getB().getP());
			mostrarRS(p.getSig());
		}
	}

	public static void mostrarRec(NodoPer p) {
		if (p != null) {
			System.out.println("["+p.getNombre()+ " " + p.getCargo()+ "] ");
			mostrarRec(p.getSig());
		}else {
			System.out.println("Fin!!!!");
		}
	}
		
	
	
}
